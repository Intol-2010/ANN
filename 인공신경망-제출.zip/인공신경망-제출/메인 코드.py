# ============================================================
# Brawl Stars 실시간 승률 중계 통합본
#
# 구성 영역
#   [1] 화면 OCR / 게임 상태 수집부     ← 원본 1.py
#   [2] 실시간 승률 예측부              ← 원본 2.py
#   [3] 최종 중계 화면 / Discord 캡처부  ← 원본 3.py
#
# 실행 방식
#   - OCR: 백그라운드 스레드에서 약 10 FPS
#   - 승률 예측: JSON 변경 시에만 예측
#   - Discord 캡처: 백그라운드에서 최대 60 FPS
#   - Pygame 중계 UI: 메인 스레드에서 60 FPS
#
# 디버깅
#   DEBUG_SHOW_ROI = True 로 설정하면
#   OCR에서 사용하는 ROI를 최종 중계 화면에 표시합니다.
# ============================================================

import os
import json
import re
import time
import threading
import subprocess
import sys

# SDL이 비활성 창을 최소화하지 않도록 pygame을 import하기 전에 설정한다.
os.environ.setdefault("SDL_VIDEO_MINIMIZE_ON_FOCUS_LOSS", "0")
os.environ.setdefault("SDL_RENDER_DRIVER", "software")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ADMIN_CONTROL_FILE = os.path.join(BASE_DIR, "admin_control.json")
ADMIN_STATUS_FILE = os.path.join(BASE_DIR, "admin_status.json")
ADMIN_PREVIEW_FILE = os.path.join(BASE_DIR, "admin_ocr_preview.png")
ROI_CONFIG_FILE = os.path.join(BASE_DIR, "ocr_roi_config.json")
ADMIN_MANUAL_FILE = os.path.join(BASE_DIR, "관리자_매뉴얼_비상연락처.txt")


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as file:
            return json.load(file)
    except (OSError, ValueError, TypeError):
        return default


def _write_json_atomic(path, data):
    temporary = f"{path}.tmp"
    with open(temporary, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)
    os.replace(temporary, path)


def admin_main():
    """관리자 전용 프로세스. Tk는 macOS에서 자신의 메인 스레드에서 실행한다."""
    import tkinter as tk
    from tkinter import ttk

    root = tk.Tk()
    root.title("브롤스타즈 중계 관리자")
    root.geometry("980x700")
    root.minsize(760, 560)

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True, padx=10, pady=10)

    state_tab = ttk.Frame(notebook, padding=18)
    debug_tab = ttk.Frame(notebook, padding=12)
    system_tab = ttk.Frame(notebook, padding=18)
    manual_tab = ttk.Frame(notebook, padding=18)
    notebook.add(state_tab, text="경기 상태 / 수동 제어")
    notebook.add(debug_tab, text="OCR 디버그")
    notebook.add(system_tab, text="캡처 상태")
    notebook.add(manual_tab, text="매뉴얼 / 비상 연락처")

    live_text = tk.StringVar(value="OCR 상태를 불러오는 중...")
    ttk.Label(state_tab, textvariable=live_text, font=("Apple SD Gothic Neo", 15, "bold")).pack(anchor="w")
    ttk.Label(
        state_tab,
        text="‘MLP 입력에 적용’을 누르면 아래 값이 OCR 값을 대신합니다. 별도 체크가 필요 없습니다.",
    ).pack(anchor="w", pady=(6, 18))

    form = ttk.Frame(state_tab)
    form.pack(anchor="w")
    red_var = tk.StringVar(value="0")
    blue_var = tk.StringVar(value="0")
    time_var = tk.StringVar(value="150")
    for row, (label, variable) in enumerate((("RED 점수 (0~2)", red_var), ("BLUE 점수 (0~2)", blue_var), ("잔여 시간 (초, 0~150)", time_var))):
        ttk.Label(form, text=label, width=22).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(form, textvariable=variable, width=12).grid(row=row, column=1, sticky="w", pady=5)

    notice = tk.StringVar(value="")
    restart_notice = tk.StringVar(value="")

    def save_control(manual_enabled):
        try:
            red = max(0, min(2, int(red_var.get())))
            blue = max(0, min(2, int(blue_var.get())))
            remaining = max(0, min(150, int(time_var.get())))
        except ValueError:
            notice.set("점수는 정수 0~2, 시간은 정수 0~150으로 입력하세요.")
            return
        control = _read_json(ADMIN_CONTROL_FILE, {})
        if not isinstance(control, dict):
            control = {}
        control.update({
            "manual_enabled": manual_enabled,
            "red_score": red,
            "blue_score": blue,
            "time_left": remaining,
            "updated_at": time.time(),
        })
        _write_json_atomic(ADMIN_CONTROL_FILE, control)
        notice.set("수동 제어로 전환했습니다. 현재 값이 MLP 입력에 적용됩니다." if manual_enabled else "OCR 입력으로 복귀했습니다.")

    buttons = ttk.Frame(state_tab)
    buttons.pack(anchor="w", pady=18)
    ttk.Button(buttons, text="MLP 입력에 적용", command=lambda: save_control(True)).pack(side="left")
    ttk.Button(buttons, text="OCR 입력으로 복귀", command=lambda: save_control(False)).pack(side="left", padx=8)
    ttk.Label(state_tab, textvariable=notice, foreground="#b04020").pack(anchor="w")

    winrate_var = tk.DoubleVar(value=50.0)
    winrate_text = tk.StringVar(value="RED 승률 수동 조작: 50.0%")
    ttk.Separator(state_tab).pack(fill="x", pady=(18, 14))
    ttk.Label(state_tab, textvariable=winrate_text, font=("Apple SD Gothic Neo", 13, "bold")).pack(anchor="w")

    def set_manual_winrate(value):
        percent = max(0.0, min(100.0, float(value)))
        winrate_var.set(percent)
        winrate_text.set(f"RED 승률 수동 조작: {percent:.1f}%")
        control = _read_json(ADMIN_CONTROL_FILE, {})
        if not isinstance(control, dict):
            control = {}
        control.update({
            "manual_red_winrate_enabled": True,
            "manual_red_winrate": percent / 100.0,
            "updated_at": time.time(),
        })
        _write_json_atomic(ADMIN_CONTROL_FILE, control)
        notice.set(f"RED 승률을 {percent:.1f}%로 수동 송출 중입니다.")

    ttk.Scale(state_tab, from_=0, to=100, variable=winrate_var, command=set_manual_winrate).pack(fill="x", pady=(6, 4))

    def restore_predicted_winrate():
        control = _read_json(ADMIN_CONTROL_FILE, {})
        if not isinstance(control, dict):
            control = {}
        control["manual_red_winrate_enabled"] = False
        control["updated_at"] = time.time()
        _write_json_atomic(ADMIN_CONTROL_FILE, control)
        notice.set("RED 승률을 MLP 자동 예측으로 복귀했습니다.")

    ttk.Button(state_tab, text="승률 MLP 자동 예측으로 복귀", command=restore_predicted_winrate).pack(anchor="w", pady=(6, 0))

    # OCR/MLP 리셋은 수동 제어와 함께 배치한다. 함수는 아래에서 정의되며 클릭 시 해석된다.
    ttk.Button(state_tab, text="내부 OCR · MLP 프로세스 재시작", command=lambda: request_pipeline_restart()).pack(anchor="w", pady=(14, 2))
    ttk.Label(state_tab, textvariable=restart_notice, foreground="#b04020").pack(anchor="w")

    ttk.Separator(state_tab).pack(fill="x", pady=(16, 12))
    ttk.Label(state_tab, text="운영 제어", font=("Apple SD Gothic Neo", 13, "bold")).pack(anchor="w")
    prediction_button_text = tk.StringVar(value="MLP 승률 예측 일시정지")
    operational_notice = tk.StringVar(value="")

    def update_operational_control(**changes):
        control = _read_json(ADMIN_CONTROL_FILE, {})
        if not isinstance(control, dict):
            control = {}
        control.update(changes)
        control["updated_at"] = time.time()
        _write_json_atomic(ADMIN_CONTROL_FILE, control)
        return control

    def toggle_prediction_pause():
        control = _read_json(ADMIN_CONTROL_FILE, {})
        paused = not (isinstance(control, dict) and control.get("prediction_paused", False))
        update_operational_control(prediction_paused=paused)
        prediction_button_text.set("MLP 승률 예측 재개" if paused else "MLP 승률 예측 일시정지")
        operational_notice.set("MLP 승률 예측을 일시정지했습니다. 현재 게이지 값을 유지합니다." if paused else "MLP 승률 예측을 재개했습니다.")

    ttk.Button(state_tab, textvariable=prediction_button_text, command=toggle_prediction_pause).pack(anchor="w", pady=(8, 4))

    def set_game_active(active):
        update_operational_control(game_active=active)
        operational_notice.set("경기를 시작했습니다. 승률 게이지를 표시합니다." if active else "경기를 종료했습니다. 승률 게이지를 숨깁니다.")

    def set_relay_enabled(enabled):
        update_operational_control(relay_enabled=enabled)
        operational_notice.set("경기 중계를 재개했습니다." if enabled else "경기 중계를 중지했습니다. 안내 문구를 송출합니다.")

    game_buttons = ttk.Frame(state_tab)
    game_buttons.pack(anchor="w", pady=(6, 4))
    ttk.Button(game_buttons, text="경기 종료", command=lambda: set_game_active(False)).pack(side="left")
    ttk.Button(game_buttons, text="경기 시작", command=lambda: set_game_active(True)).pack(side="left", padx=8)

    relay_buttons = ttk.Frame(state_tab)
    relay_buttons.pack(anchor="w", pady=(4, 2))
    ttk.Button(relay_buttons, text="경기 중계 중지", command=lambda: set_relay_enabled(False)).pack(side="left")
    ttk.Button(relay_buttons, text="경기 중계 재개", command=lambda: set_relay_enabled(True)).pack(side="left", padx=8)
    ttk.Label(state_tab, textvariable=operational_notice, foreground="#b04020").pack(anchor="w")

    ttk.Label(debug_tab, text="내부 드래그: 위치 이동 · 테두리/모서리 조절점 드래그: 폭·높이·비율 조정", font=("Apple SD Gothic Neo", 13, "bold")).pack(anchor="w")
    preview_canvas = tk.Canvas(debug_tab, background="#111116", highlightthickness=0)
    preview_canvas.pack(fill="both", expand=True, pady=(10, 0))
    preview_image = None
    preview_mtime = None
    preview_origin = (0, 0)
    preview_scale = (1.0, 1.0)
    preview_size = (0, 0)
    source_size = (0, 0)
    active_drag = None
    roi_colors = {"red_score": "#ff3446", "blue_score": "#3478ff", "time": "#ffdc46"}
    roi_labels = {"red_score": "RED SCORE", "blue_score": "BLUE SCORE", "time": "TIME"}
    roi_defaults = {"red_score": [2300, 230, 120, 80], "blue_score": [140, 230, 120, 80], "time": [1200, 230, 170, 80]}
    roi_config = _read_json(ROI_CONFIG_FILE, roi_defaults)

    def valid_rois(data):
        if not isinstance(data, dict):
            data = {}
        return {
            key: [int(v) for v in data.get(key, fallback)]
            if isinstance(data.get(key, fallback), (list, tuple)) and len(data.get(key, fallback)) == 4
            else list(fallback)
            for key, fallback in roi_defaults.items()
        }

    roi_config = valid_rois(roi_config)
    handle_radius = 6

    def bbox_on_canvas(roi):
        x, y, width, height = roi
        x0, y0 = preview_origin
        sx, sy = preview_scale
        return x0 + x * sx, y0 + y * sy, x0 + (x + width) * sx, y0 + (y + height) * sy

    def resize_handles(left, top, right, bottom):
        middle_x = (left + right) / 2
        middle_y = (top + bottom) / 2
        return {
            "nw": (left, top), "n": (middle_x, top), "ne": (right, top),
            "e": (right, middle_y), "se": (right, bottom), "s": (middle_x, bottom),
            "sw": (left, bottom), "w": (left, middle_y),
        }

    def draw_rois():
        preview_canvas.delete("all")
        if preview_image is None:
            preview_canvas.create_text(460, 260, text="OCR 프레임 대기 중...", fill="white")
            return
        x0, y0 = preview_origin
        preview_canvas.create_image(x0, y0, image=preview_image, anchor="nw")
        sx, sy = preview_scale
        for key, roi in roi_config.items():
            left, top, right, bottom = bbox_on_canvas(roi)
            preview_canvas.create_rectangle(left, top, right, bottom, outline=roi_colors[key], width=3, tags=("roi", key))
            preview_canvas.create_text(left + 4, top - 10, text=roi_labels[key], fill=roi_colors[key], anchor="sw", font=("Helvetica", 11, "bold"), tags=("roi", key))
            # 8개 조절점: 모서리는 가로/세로 동시 조절, 변 중앙은 한 방향만 조절
            for handle_x, handle_y in resize_handles(left, top, right, bottom).values():
                preview_canvas.create_rectangle(
                    handle_x - handle_radius, handle_y - handle_radius,
                    handle_x + handle_radius, handle_y + handle_radius,
                    fill=roi_colors[key], outline="white", width=1,
                )

    def on_press(event):
        nonlocal active_drag
        # 겹치는 BBox가 있으면 마지막으로 그린 BBox를 우선 선택한다.
        for key in reversed(list(roi_config)):
            left, top, right, bottom = bbox_on_canvas(roi_config[key])
            for handle, (handle_x, handle_y) in resize_handles(left, top, right, bottom).items():
                if abs(event.x - handle_x) <= handle_radius and abs(event.y - handle_y) <= handle_radius:
                    active_drag = ("resize", key, handle)
                    preview_canvas.configure(cursor="crosshair")
                    return
            if left <= event.x <= right and top <= event.y <= bottom:
                sx, sy = preview_scale
                active_drag = ("move", key, ((event.x - left) / sx, (event.y - top) / sy))
                preview_canvas.configure(cursor="fleur")
                return

    def on_drag(event):
        if active_drag is None or source_size[0] <= 0:
            return
        mode, key, detail = active_drag
        sx, sy = preview_scale
        x0, y0 = preview_origin
        x, y, width, height = roi_config[key]
        if mode == "move":
            offset_x, offset_y = detail
            new_x = round((event.x - x0) / sx - offset_x)
            new_y = round((event.y - y0) / sy - offset_y)
            roi_config[key][0] = max(0, min(source_size[0] - width, new_x))
            roi_config[key][1] = max(0, min(source_size[1] - height, new_y))
        else:
            # 반대쪽 변은 고정한 상태로 선택한 변/모서리만 움직인다.
            handle = detail
            pointer_x = max(0, min(source_size[0], round((event.x - x0) / sx)))
            pointer_y = max(0, min(source_size[1], round((event.y - y0) / sy)))
            left, top, right, bottom = x, y, x + width, y + height
            if "w" in handle:
                left = min(pointer_x, right - 1)
            if "e" in handle:
                right = max(pointer_x, left + 1)
            if "n" in handle:
                top = min(pointer_y, bottom - 1)
            if "s" in handle:
                bottom = max(pointer_y, top + 1)
            roi_config[key] = [left, top, right - left, bottom - top]
        draw_rois()

    def on_release(_event):
        nonlocal active_drag
        if active_drag is not None:
            _write_json_atomic(ROI_CONFIG_FILE, roi_config)
            active_drag = None
            preview_canvas.configure(cursor="")

    preview_canvas.bind("<ButtonPress-1>", on_press)
    preview_canvas.bind("<B1-Motion>", on_drag)
    preview_canvas.bind("<ButtonRelease-1>", on_release)

    capture_text = tk.StringVar(value="캡처 상태를 불러오는 중...")
    ttk.Label(system_tab, textvariable=capture_text, justify="left", font=("Menlo", 13)).pack(anchor="nw", fill="both", expand=True)

    def request_pipeline_restart():
        control = _read_json(ADMIN_CONTROL_FILE, {})
        if not isinstance(control, dict):
            control = {}
        control["restart_request_id"] = time.time_ns()
        control["updated_at"] = time.time()
        _write_json_atomic(ADMIN_CONTROL_FILE, control)
        restart_notice.set("중계 화면은 검정 화면을 유지하고 OCR·MLP 작업을 재시작합니다.")


    ttk.Label(manual_tab, text="운영 매뉴얼 / 비상시 연락처", font=("Apple SD Gothic Neo", 15, "bold")).pack(anchor="w")
    ttk.Label(manual_tab, text="이 내용은 관리자 전용 텍스트 파일로 저장되며 다음 실행에도 유지됩니다.").pack(anchor="w", pady=(5, 10))
    manual_editor = tk.Text(manual_tab, wrap="word", font=("Apple SD Gothic Neo", 13))
    manual_editor.pack(fill="both", expand=True)
    try:
        with open(ADMIN_MANUAL_FILE, "r", encoding="utf-8") as file:
            manual_editor.insert("1.0", file.read())
    except OSError:
        manual_editor.insert("1.0", "[운영 매뉴얼]\n\n[비상 연락처]\n담당자: \n전화: \n\n[장애 대응 순서]\n1. OCR 디버그에서 BBox 확인\n2. 수동 제어로 전환\n3. 내부 OCR · MLP 프로세스 재시작\n")

    manual_notice = tk.StringVar(value="")
    def save_manual():
        temporary = f"{ADMIN_MANUAL_FILE}.tmp"
        with open(temporary, "w", encoding="utf-8") as file:
            file.write(manual_editor.get("1.0", "end-1c"))
        os.replace(temporary, ADMIN_MANUAL_FILE)
        manual_notice.set("매뉴얼을 저장했습니다.")
    ttk.Button(manual_tab, text="매뉴얼 저장", command=save_manual).pack(anchor="e", pady=(8, 0))
    ttk.Label(manual_tab, textvariable=manual_notice).pack(anchor="e")

    def refresh():
        nonlocal preview_image, preview_mtime, preview_origin, preview_scale, preview_size, source_size, roi_config
        game = _read_json(os.path.join(BASE_DIR, "game_state.json"), {})
        winrate = _read_json(os.path.join(BASE_DIR, "winrate.json"), {})
        status = _read_json(ADMIN_STATUS_FILE, {})
        red = game.get("red_score", "-")
        blue = game.get("blue_score", "-")
        remaining = game.get("time_left", "-")
        rate = winrate.get("red_winrate")
        rate_text = "-" if rate is None else f"{float(rate) * 100:.1f}%"
        control = _read_json(ADMIN_CONTROL_FILE, {})
        if isinstance(control, dict) and control.get("manual_red_winrate_enabled"):
            source = "RED 승률 수동"
        else:
            source = "수동 입력" if status.get("manual_enabled") else "OCR"
        if not isinstance(control, dict):
            control = {}
        prediction_button_text.set("MLP 승률 예측 재개" if control.get("prediction_paused", False) else "MLP 승률 예측 일시정지")
        game_status = "경기 진행" if control.get("game_active", True) else "경기 종료"
        relay_status = "중계 송출" if control.get("relay_enabled", True) else "중계 중지"
        live_text.set(f"현재 MLP 입력  |  RED {red} : BLUE {blue}  |  잔여 {remaining}초  |  RED 승률 {rate_text}  |  {source} · {game_status} · {relay_status}")
        capture_text.set(
            f"OCR 캡처 원본: {status.get('source', '-') }\n"
            f"Discord 창 좌표: {status.get('region', '-') }\n"
            f"실제 캡처 프레임: {status.get('frame_size', '-') }\n"
            f"마지막 갱신: {status.get('updated_at_text', '-') }\n\n"
            "문제 해결 순서\n"
            "1. OCR 디버그 탭에서 BBox가 점수/시간 위에 있는지 확인\n"
            "2. OCR 디버그 탭에서 BBox를 끌어 위치를 조정\n"
            "3. 긴급 상황에서는 경기 상태 / 수동 제어 탭에서 MLP 입력을 직접 지정"
        )
        try:
            mtime = os.path.getmtime(ADMIN_PREVIEW_FILE)
            if mtime != preview_mtime:
                preview_image = tk.PhotoImage(file=ADMIN_PREVIEW_FILE)
                preview_size = (preview_image.width(), preview_image.height())
                source_size = (int(status.get("frame_width", 0)), int(status.get("frame_height", 0)))
                canvas_w = max(preview_canvas.winfo_width(), preview_size[0])
                canvas_h = max(preview_canvas.winfo_height(), preview_size[1])
                preview_origin = ((canvas_w - preview_size[0]) // 2, (canvas_h - preview_size[1]) // 2)
                if source_size[0] > 0 and source_size[1] > 0:
                    preview_scale = (preview_size[0] / source_size[0], preview_size[1] / source_size[1])
                roi_config = valid_rois(_read_json(ROI_CONFIG_FILE, roi_config))
                draw_rois()
                preview_mtime = mtime
        except (OSError, tk.TclError):
            pass
        root.after(500, refresh)

    refresh()
    root.mainloop()


# 관리자 창은 모델/TensorFlow를 불러오지 않는 별도 프로세스로 실행한다.
if "--admin" in sys.argv:
    admin_main()
    raise SystemExit(0)

import cv2
import numpy as np
import pytesseract
import mss
import pygame
from tensorflow.keras.models import load_model
import joblib


# ============================================================
# ============================================================
# [1] 화면 OCR / 게임 상태 수집부 - 원본 1.py 영역
# ============================================================
# ============================================================

# ============================================================
# 설정
# ============================================================

DEBUG_SHOW_ROI = True

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

TESSERACT_PATH = "/opt/homebrew/bin/tesseract" # 본인 맥에 맞게 수정하세요
pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

JSON_FILE = os.path.join(BASE_DIR, "game_state.json")
MONITOR_INDEX = 2

# OCR과 중계 화면이 반드시 같은 픽셀을 보도록 합니다.
# "discord"(권장): Discord 창 내부의 왼쪽 위를 (0, 0)으로 하는 ROI
# "monitor"         : 아래 MONITOR_INDEX 모니터의 왼쪽 위를 (0, 0)으로 하는 ROI
#
# macOS의 AppleScript 창 좌표는 포인트(point)이고, Retina/외부 모니터의
# 화면 캡처는 픽셀일 수 있습니다. 이전 버전은 OCR과 BBox에 이 좌표계를
# 섞어 사용해, 다중 모니터에서 BBox가 사라지고 엉뚱한 영역을 OCR했습니다.
OCR_CAPTURE_SOURCE = "discord"

# # ROI (모니터 해상도에 맞춰 조정 필요)
# RED_SCORE_ROI = (2250, 30, 100, 90)
# BLUE_SCORE_ROI = (210, 40, 120, 80)
# TIME_ROI = (1200, 50, 150, 60)
RED_SCORE_ROI = (2300, 230, 120, 80)
BLUE_SCORE_ROI = (140, 230, 120, 80)
TIME_ROI = (1200, 230, 170, 80)
_LAST_ROI_CONFIG_CHECK = 0.0


def refresh_roi_config():
    """관리자 창에서 저장한 BBox 위치를 OCR 루프에 반영한다."""
    global RED_SCORE_ROI, BLUE_SCORE_ROI, TIME_ROI, _LAST_ROI_CONFIG_CHECK
    now = time.monotonic()
    if now - _LAST_ROI_CONFIG_CHECK < 0.2:
        return
    _LAST_ROI_CONFIG_CHECK = now
    data = _read_json(ROI_CONFIG_FILE, {})
    if not isinstance(data, dict):
        return
    try:
        def read_roi(key, fallback):
            values = data.get(key, fallback)
            if not isinstance(values, (list, tuple)) or len(values) != 4:
                return fallback
            x, y, width, height = (int(v) for v in values)
            return (max(0, x), max(0, y), max(1, width), max(1, height))
        RED_SCORE_ROI = read_roi("red_score", RED_SCORE_ROI)
        BLUE_SCORE_ROI = read_roi("blue_score", BLUE_SCORE_ROI)
        TIME_ROI = read_roi("time", TIME_ROI)
    except (TypeError, ValueError):
        pass

# ============================================================
# 전역 변수 (인식 실패 시 이전 값을 유지하기 위함)
# ============================================================
last_red_score = 0
last_blue_score = 0
last_time_left = 150

screen = mss.mss()


def get_ocr_monitor():
    """MONITOR_INDEX 오류가 나도 전체 화면 캡처로 안전하게 대체합니다."""
    monitors = screen.monitors
    if 0 <= MONITOR_INDEX < len(monitors):
        return monitors[MONITOR_INDEX]
    print(f"[OCR] MONITOR_INDEX={MONITOR_INDEX}를 찾지 못해 전체 화면을 사용합니다.")
    return monitors[0]


monitor = get_ocr_monitor()
OCR_DISCORD_REGION_CACHE = None
OCR_DISCORD_REGION_REFRESH_AT = 0.0


def capture_screen(sct):
    """OCR 프레임과 그 프레임의 좌표 원점을 함께 반환합니다.

    Discord 모드에서는 OCR과 중계 화면 모두 같은 Discord 창 캡처를 사용한다.
    따라서 ROI와 디버그 BBox가 외부 모니터의 배율/원점과 무관하게 일치한다.
    """
    global OCR_DISCORD_REGION_CACHE, OCR_DISCORD_REGION_REFRESH_AT

    region = None
    if OCR_CAPTURE_SOURCE == "discord":
        # AppleScript는 비용이 크므로 초당 두 번만 창 위치를 갱신합니다.
        # get_discord_region은 아래 중계부에 정의되어 있으며 실행 시점에는 준비됨.
        now = time.monotonic()
        if now >= OCR_DISCORD_REGION_REFRESH_AT:
            found_region = get_discord_region()
            if found_region is not None:
                OCR_DISCORD_REGION_CACHE = found_region
            OCR_DISCORD_REGION_REFRESH_AT = now + 0.5
        region = OCR_DISCORD_REGION_CACHE
        if region is None:
            return None, None
    else:
        region = monitor

    try:
        screenshot = sct.grab(region)
    except Exception as exc:
        print(f"[OCR] 화면 캡처 실패: {type(exc).__name__}: {exc}")
        return None, None

    frame = np.array(screenshot)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    return frame, dict(region)


def crop_roi(frame, roi):
    if frame is None:
        return None
    x, y, width, height = roi
    frame_h, frame_w = frame.shape[:2]
    left, top = max(0, x), max(0, y)
    right, bottom = min(frame_w, x + width), min(frame_h, y + height)
    if right <= left or bottom <= top:
        return None
    return frame[top:bottom, left:right]

# ============================================================
# OCR 디버그 이미지
# ============================================================
DEBUG_OCR_IMAGES = {
    "RED SCORE": None,
    "BLUE SCORE": None,
    "TIME": None
}

# 디버그 UI에는 이진화 결과 대신 실제로 잘라낸 원본 영역을 보여 준다.
# 이진화 결과만 보면 정상 영역도 흰색/검은색으로 보이기 때문이다.
DEBUG_RAW_ROI_IMAGES = {
    "RED SCORE": None,
    "BLUE SCORE": None,
    "TIME": None,
}

DEBUG_OCR_LOCK = threading.Lock()

# 관리자 창에 0.5초 간격으로 OCR 원본 프레임/BBox 정보를 발행합니다.
_LAST_ADMIN_PREVIEW_AT = 0.0


def get_manual_state():
    """관리자 창의 수동 입력이 활성화된 경우에만 MLP 입력값을 반환한다."""
    control = _read_json(ADMIN_CONTROL_FILE, {})
    if not control.get("manual_enabled", False):
        return None
    try:
        return (
            max(0, min(2, int(control["red_score"]))),
            max(0, min(2, int(control["blue_score"]))),
            max(0, min(150, int(control["time_left"]))),
        )
    except (KeyError, TypeError, ValueError):
        return None


def get_manual_red_winrate():
    """관리자 슬라이더가 활성화된 동안 결과 중계에 보낼 RED 승률을 반환한다."""
    control = _read_json(ADMIN_CONTROL_FILE, {})
    if not isinstance(control, dict) or not control.get("manual_red_winrate_enabled", False):
        return None
    try:
        return max(0.0, min(1.0, float(control["manual_red_winrate"])))
    except (KeyError, TypeError, ValueError):
        return None


def get_operational_state():
    """관리자 운영 제어값. 설정이 없으면 모든 기능을 정상 송출한다."""
    control = _read_json(ADMIN_CONTROL_FILE, {})
    if not isinstance(control, dict):
        control = {}
    return {
        "prediction_paused": bool(control.get("prediction_paused", False)),
        "game_active": bool(control.get("game_active", True)),
        "relay_enabled": bool(control.get("relay_enabled", True)),
    }


def publish_admin_debug(frame, region):
    """관리자 창이 읽을 수 있도록 원본 OCR 화면을 PNG로 저장한다."""
    global _LAST_ADMIN_PREVIEW_AT
    now = time.monotonic()
    if frame is None or now - _LAST_ADMIN_PREVIEW_AT < 0.5:
        return
    _LAST_ADMIN_PREVIEW_AT = now

    preview = frame.copy()
    frame_h, frame_w = preview.shape[:2]
    scale = min(1.0, 920 / max(1, frame_w), 560 / max(1, frame_h))
    if scale < 1.0:
        preview = cv2.resize(preview, (int(frame_w * scale), int(frame_h * scale)), interpolation=cv2.INTER_AREA)
    temporary = f"{ADMIN_PREVIEW_FILE}.tmp.png"
    try:
        cv2.imwrite(temporary, preview)
        os.replace(temporary, ADMIN_PREVIEW_FILE)
        _write_json_atomic(ADMIN_STATUS_FILE, {
            "source": "Discord 창 내부 좌표",
            "region": {key: int(value) for key, value in (region or {}).items()},
            "frame_size": f"{frame_w} x {frame_h}",
            "frame_width": frame_w,
            "frame_height": frame_h,
            "manual_enabled": get_manual_state() is not None,
            "updated_at_text": time.strftime("%H:%M:%S"),
        })
    except OSError as exc:
        print(f"[관리자] 디버그 이미지 저장 실패: {exc}")


def update_debug_ocr_image(name, image):
    if not DEBUG_SHOW_ROI:
        return

    with DEBUG_OCR_LOCK:
        DEBUG_OCR_IMAGES[name] = None if image is None else image.copy()


def update_debug_raw_roi(name, image):
    if not DEBUG_SHOW_ROI:
        return
    with DEBUG_OCR_LOCK:
        DEBUG_RAW_ROI_IMAGES[name] = None if image is None else image.copy()

# ============================================================
# OCR 전처리
# ============================================================
def preprocess_for_ocr(image):
    if image is None or image.size == 0:
        return None
    # 1. 흑백(Grayscale) 변환
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 2. 이진화 및 반전 (THRESH_BINARY_INV)
    # 임계값 180 이상인 밝은 색(흰색 폰트)은 0(검정)으로, 나머지는 255(흰색 배경)로 변경
    _, binary = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY_INV)

    return binary

# ============================================================
# 숫자 읽기 (점수용)
# ============================================================
def read_number(image, debug_name):
    processed = preprocess_for_ocr(image)

    if processed is None:
        update_debug_ocr_image(debug_name, None)
        return None

    # OCR 모델에 실제로 전달되는 이미지 저장
    update_debug_ocr_image(debug_name, processed)

    # psm 8: 단일 단어(숫자 1개)에 최적화
    config = "--psm 8 -c tessedit_char_whitelist=012"
    text = pytesseract.image_to_string(processed, config=config)
    numbers = re.findall(r"(\d+)", text)

    if not numbers:
        return None

    try:
        return int(numbers[0])
    except ValueError:
        return None
# ============================================================
# 시간 읽기
# ============================================================
def read_time(image):
    processed = preprocess_for_ocr(image)

    if processed is None:
        update_debug_ocr_image("TIME", None)
        return None

    # OCR 모델에 실제로 전달되는 이미지 저장
    update_debug_ocr_image("TIME", processed)

    # psm 7: 단일 텍스트 줄 인식
    config = "--psm 7 -c tessedit_char_whitelist=0123456789:"
    text = pytesseract.image_to_string(processed, config=config)
    text = text.strip()

    match = re.search(r"(\d+):(\d+)", text)

    if not match:
        return None

    minutes = int(match.group(1))
    seconds = int(match.group(2))

    return minutes * 60 + seconds
# ============================================================
# JSON 저장
# ============================================================
def save_game_state(red, blue, time_left):
    data = {
        "red_score": red,
        "blue_score": blue,
        "time_left": time_left,
        "red_deaths": 0,
        "blue_deaths": 0
    }
    with open(JSON_FILE, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=4)

# ============================================================
# 메인 루프
# ============================================================
def main_ocr():
    global last_red_score, last_blue_score, last_time_left

    print("==============================")
    print(" Brawl Stars Screen Reader Mac V2 (Background Mode)")
    print("==============================")
    print("실행 중입니다. 종료하려면 터미널에서 Ctrl+C를 누르세요.")

    # mss 객체는 만든 스레드에서만 사용합니다. macOS에서 메인 스레드에서
    # 만든 객체를 OCR 스레드가 사용하면 검정/흰 프레임이 나올 수 있습니다.
    ocr_sct = mss.mss()

    try:
        while RUNNING.is_set() and WORKERS_RUNNING.is_set():
            frame, ocr_region = capture_screen(ocr_sct)
            if frame is None:
                # Discord가 열려 있지 않거나 화면 기록 권한이 없는 경우.
                time.sleep(0.25)
                continue

            refresh_roi_config()
            # 결과 중계 화면이 아니라 독립 관리자 창에서 원본 OCR 화면을 확인한다.
            publish_admin_debug(frame, ocr_region)

            red_img = crop_roi(frame, RED_SCORE_ROI)
            blue_img = crop_roi(frame, BLUE_SCORE_ROI)
            time_img = crop_roi(frame, TIME_ROI)

            update_debug_raw_roi("RED SCORE", red_img)
            update_debug_raw_roi("BLUE SCORE", blue_img)
            update_debug_raw_roi("TIME", time_img)

            red_score = read_number(red_img, "RED SCORE")
            blue_score = read_number(blue_img, "BLUE SCORE")
            remaining_time = read_time(time_img)

            manual_state = get_manual_state()
            if manual_state is not None:
                red_score, blue_score, remaining_time = manual_state

            # 상태 유지 로직: 숫자를 제대로 읽었다면 변수 갱신, 못 읽었다면 이전 값 사용
            if red_score is not None:
                last_red_score = red_score
            if blue_score is not None:
                last_blue_score = blue_score
            if remaining_time is not None:
                last_time_left = remaining_time

            print(f"RED: {last_red_score} | BLUE: {last_blue_score} | TIME: {last_time_left}")

            save_game_state(last_red_score, last_blue_score, last_time_left)

            # CPU 점유율 최적화를 위한 짧은 대기 시간 (UI 창 대기 역할을 대신함)
            time.sleep(0.1)

    except KeyboardInterrupt:
        print("\n프로그램을 종료합니다.")


# ============================================================
# ============================================================
# [2] 실시간 승률 예측부 - V5 경기 흐름 모델
# ============================================================
# ============================================================

# V5 모델은 현재 점수/시간뿐 아니라 경기 이력을 사용합니다.
# OCR에서 새로 얻는 값은 red_score / blue_score / time_left이고,
# 아래 예측부가 그 변화 이력을 이용해 나머지 feature를 자동 계산합니다.

import collections
import tensorflow as tf
from tensorflow.keras.models import load_model

MODEL_PATH = os.path.join(BASE_DIR, "brawl_win_model_flow_v5.keras")
SCALER_PATH = os.path.join(BASE_DIR, "brawl_flow_scaler_v5.pkl")
INPUT_JSON_PATH = JSON_FILE
OUTPUT_JSON_PATH = os.path.join(BASE_DIR, "winrate.json")
POLL_INTERVAL = 0.1

MAX_TIME = 150
TARGET_TIME_ANCHORS = np.array(
    [150, 100, 50, 30, 20, 10, 5, 0],
    dtype=np.float64,
)
TARGET_ONE_GOAL = np.array(
    [0.55, 0.65, 0.70, 0.74, 0.77, 0.85, 0.92, 0.93],
    dtype=np.float64,
)

FEATURE_NAMES = [
    "red_score", "blue_score", "time_left",
    "elapsed_time", "time_progress", "time_weight",
    "late_game_factor", "end_game_factor",
    "score_diff", "total_score", "lead_abs", "lead_ratio",
    "red_is_leading", "blue_is_leading",
    "lead_duration", "lead_duration_ratio",
    "last_goal_team", "time_since_last_goal", "score_frozen_duration",
    "goal_was_recent",
    "red_goals_10s", "blue_goals_10s",
    "red_goals_20s", "blue_goals_20s",
    "red_goals_30s", "blue_goals_30s",
    "goal_momentum_10s", "goal_momentum_30s",
    "score_time_effect", "lead_time_effect", "momentum_time_effect",
]

# ------------------------------------------------------------
# V5 custom model 재구성
# 학습 코드에서 ResidualWinrateModel이라는 custom Keras class를 사용하므로
# 실행 파일에서도 동일한 class definition이 필요합니다.
# ------------------------------------------------------------
from tensorflow.keras import Model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import register_keras_serializable


@register_keras_serializable(package="BrawlBall")
class ResidualWinrateModel(Model):
    def __init__(
        self,
        feature_dim,
        scaler_mean,
        scaler_scale,
        residual_scale=0.30,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.feature_dim = int(feature_dim)
        self.residual_scale = float(residual_scale)
        self.scaler_mean = tf.constant(
            np.asarray(scaler_mean, dtype=np.float32),
            dtype=tf.float32,
        )
        self.scaler_scale = tf.constant(
            np.asarray(scaler_scale, dtype=np.float32),
            dtype=tf.float32,
        )
        self.d1 = Dense(64, activation="relu")
        self.drop1 = Dropout(0.08)
        self.d2 = Dense(48, activation="relu")
        self.drop2 = Dropout(0.06)
        self.d3 = Dense(24, activation="relu")
        self.residual_head = Dense(1, activation="tanh")

    def call(self, inputs, training=False):
        raw = inputs * self.scaler_scale + self.scaler_mean
        diff_idx = FEATURE_NAMES.index("score_diff")
        time_weight_idx = FEATURE_NAMES.index("time_weight")
        raw_score_diff = raw[:, diff_idx]
        raw_time_weight = raw[:, time_weight_idx]
        baseline_logit = tf.expand_dims(
            raw_score_diff * raw_time_weight,
            axis=-1,
        )
        x = self.d1(inputs)
        x = self.drop1(x, training=training)
        x = self.d2(x)
        x = self.drop2(x, training=training)
        x = self.d3(x)
        residual = self.residual_head(x) * self.residual_scale
        return tf.math.sigmoid(baseline_logit + residual)

    def get_config(self):
        config = super().get_config()
        config.update({
            "feature_dim": self.feature_dim,
            "scaler_mean": self.scaler_mean.numpy().tolist(),
            "scaler_scale": self.scaler_scale.numpy().tolist(),
            "residual_scale": self.residual_scale,
        })
        return config


# ------------------------------------------------------------
# 시간 가중치: 학습 코드와 동일한 smoothstep 곡선
# ------------------------------------------------------------
def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -20.0, 20.0)))


def _logit(p):
    p = np.clip(p, 1e-5, 1.0 - 1e-5)
    return np.log(p / (1.0 - p))


def _smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def time_target_probability(time_left):
    t = float(time_left)
    if t >= 150:
        return float(TARGET_ONE_GOAL[0])
    if t <= 0:
        return float(TARGET_ONE_GOAL[-1])
    for i in range(len(TARGET_TIME_ANCHORS) - 1):
        high = TARGET_TIME_ANCHORS[i]
        low = TARGET_TIME_ANCHORS[i + 1]
        if low <= t <= high:
            x = (high - t) / (high - low)
            s = _smoothstep(x)
            return float(
                TARGET_ONE_GOAL[i]
                + (TARGET_ONE_GOAL[i + 1] - TARGET_ONE_GOAL[i]) * s
            )
    return 0.55


TIME_WEIGHT_TABLE = {
    t: _logit(time_target_probability(t))
    for t in range(MAX_TIME + 1)
}


def get_time_weight(time_left):
    t = int(np.clip(round(float(time_left)), 0, MAX_TIME))
    return TIME_WEIGHT_TABLE[t]


# ------------------------------------------------------------
# 경기 이력 상태
# ------------------------------------------------------------
# (elapsed_time, red_score, blue_score)
score_history = collections.deque(maxlen=256)

def reset_prediction_history():
    score_history.clear()


def get_recent_goal_counts(now_elapsed, window):
    red_count = 0
    blue_count = 0
    cutoff = now_elapsed - window

    previous = None
    for elapsed, red, blue in score_history:
        if elapsed <= cutoff:
            previous = (elapsed, red, blue)
            continue

        if previous is not None:
            _, prev_red, prev_blue = previous
            if red > prev_red:
                red_count += 1
            if blue > prev_blue:
                blue_count += 1
        previous = (elapsed, red, blue)

    return red_count, blue_count


def infer_score_change(now_elapsed, red_score, blue_score):
    """현재 관측값을 이전 관측과 비교해 득점 팀을 추정합니다."""
    if not score_history:
        return 0

    _, prev_red, prev_blue = score_history[-1]
    if red_score > prev_red:
        return 1
    if blue_score > prev_blue:
        return -1
    return 0


def build_live_feature_row(
    red_score,
    blue_score,
    time_left,
):
    """
    V5 학습 코드와 동일한 31개 feature를 생성합니다.

    사용자에게 직접 제공받는 값:
        red_score / blue_score / time_left

    자동 계산:
        elapsed, time weight, lead duration, last goal,
        score frozen duration, recent 10/20/30 sec goals,
        momentum, interaction features
    """
    red_score = int(np.clip(red_score, 0, 2))
    blue_score = int(np.clip(blue_score, 0, 2))
    time_left = int(np.clip(time_left, 0, MAX_TIME))

    elapsed = MAX_TIME - time_left
    progress = elapsed / MAX_TIME
    diff = red_score - blue_score
    total = red_score + blue_score

    # 현재 score/time을 이력에 기록하기 전에 변화 여부를 계산
    goal_team = infer_score_change(
        elapsed,
        red_score,
        blue_score,
    )

    if goal_team != 0:
        last_goal_team = goal_team
        last_goal_elapsed = elapsed
    else:
        # 이전 이력에서 마지막 득점 시점을 추적
        last_goal_team = 0
        last_goal_elapsed = None
        prev = None
        for record in reversed(score_history):
            rec_elapsed, rec_red, rec_blue = record
            if prev is not None:
                _, next_red, next_blue = prev
                if next_red > rec_red:
                    last_goal_team = 1
                    last_goal_elapsed = rec_elapsed
                    break
                if next_blue > rec_blue:
                    last_goal_team = -1
                    last_goal_elapsed = rec_elapsed
                    break
            prev = record

    # 새 상태를 history에 등록
    score_history.append(
        (elapsed, red_score, blue_score)
    )

    # 실제 득점/점수 변경 이벤트를 시간순으로 계산
    score_events = []
    previous_record = None
    for rec_elapsed, rec_red, rec_blue in score_history:
        if previous_record is not None:
            _, prev_red, prev_blue = previous_record
            if rec_red > prev_red:
                score_events.append((rec_elapsed, 1))
            elif rec_blue > prev_blue:
                score_events.append((rec_elapsed, -1))
        previous_record = (rec_elapsed, rec_red, rec_blue)

    if score_events:
        last_goal_elapsed, last_goal_team = score_events[-1]
        time_since_last_goal = max(
            0,
            elapsed - last_goal_elapsed,
        )
    else:
        time_since_last_goal = elapsed
        last_goal_team = 0

    # 마지막 점수 변경 시점
    if score_events:
        score_changed_elapsed = score_events[-1][0]
    else:
        score_changed_elapsed = 0

    score_frozen_duration = max(
        0,
        elapsed - score_changed_elapsed,
    )

    # 현재 lead가 시작된 시점
    # 최근 기록부터 거슬러 올라가며 같은 score difference가
    # 언제부터 연속되었는지 찾습니다.
    lead_duration = 0
    if diff != 0:
        lead_start_elapsed = elapsed
        for idx in range(len(score_history) - 1, -1, -1):
            rec_elapsed, rec_red, rec_blue = score_history[idx]
            rec_diff = rec_red - rec_blue
            if rec_diff != diff:
                break
            lead_start_elapsed = rec_elapsed
        lead_duration = max(
            0,
            elapsed - lead_start_elapsed,
        )

    red_goals_10s, blue_goals_10s = get_recent_goal_counts(elapsed, 10)
    red_goals_20s, blue_goals_20s = get_recent_goal_counts(elapsed, 20)
    red_goals_30s, blue_goals_30s = get_recent_goal_counts(elapsed, 30)

    lead_abs = abs(diff)
    lead_ratio = lead_abs / total if total else 0.0

    red_is_leading = int(diff > 0)
    blue_is_leading = int(diff < 0)

    time_weight = get_time_weight(time_left)

    goal_was_recent = int(
        time_since_last_goal <= 8
    )

    momentum10 = red_goals_10s - blue_goals_10s
    momentum30 = red_goals_30s - blue_goals_30s

    late_game_factor = progress ** 1.8
    end_game_factor = progress ** 4

    score_time_effect = diff * time_weight

    lead_time_effect = (
        np.sign(diff)
        * min(lead_duration / 60.0, 1.0)
        * time_weight
    )

    momentum_time_effect = (
        np.tanh(momentum30 / 1.5)
        * (0.25 + 0.75 * progress)
    )

    return np.array([
        red_score,
        blue_score,
        time_left,
        elapsed,
        progress,
        time_weight,
        late_game_factor,
        end_game_factor,
        diff,
        total,
        lead_abs,
        lead_ratio,
        red_is_leading,
        blue_is_leading,
        lead_duration,
        min(lead_duration / MAX_TIME, 1.0),
        last_goal_team,
        time_since_last_goal,
        score_frozen_duration,
        goal_was_recent,
        red_goals_10s,
        blue_goals_10s,
        red_goals_20s,
        blue_goals_20s,
        red_goals_30s,
        blue_goals_30s,
        momentum10,
        momentum30,
        score_time_effect,
        lead_time_effect,
        momentum_time_effect,
    ], dtype=np.float32)


# ------------------------------------------------------------
# 모델 / scaler 로드
# ------------------------------------------------------------
print(f"[{MODEL_PATH}] 및 [{SCALER_PATH}] 로드 중...")
try:
    scaler = joblib.load(SCALER_PATH)

    # custom model을 안전하게 로드하기 위해 class 등록을 명시
    model = load_model(
        MODEL_PATH,
        custom_objects={
            "ResidualWinrateModel": ResidualWinrateModel,
        },
        compile=False,
    )

    print("-> V5 모델 / scaler 로드 완료! 실시간 예측 대기 중...\n")
except FileNotFoundError:
    print("에러: V5 모델이나 scaler 파일이 없습니다. 경로를 확인해주세요.")
    model = None
    scaler = None
except Exception as e:
    print(f"에러: V5 모델 로드 실패: {e}")
    model = None
    scaler = None

# 이전 파일의 수정 시간을 기록하여, 파일이 갱신되었을 때만 연산
last_modified_time = 0
last_observed_time = None


# ==========================================
# 3. 실시간 감지 및 예측 루프
# ==========================================
def main_prediction():
    global last_modified_time, last_observed_time

    if model is None or scaler is None:
        return

    reset_prediction_history()
    last_observed_time = None

    while RUNNING.is_set() and WORKERS_RUNNING.is_set():
        manual_winrate = get_manual_red_winrate()
        if manual_winrate is not None:
            # 슬라이더 값은 점수/시간 MLP 입력과 독립적으로 최종 중계 승률을 덮어쓴다.
            try:
                with open(OUTPUT_JSON_PATH, "w", encoding="utf-8") as f:
                    json.dump({"red_winrate": manual_winrate}, f)
            except OSError as exc:
                print(f"수동 승률 저장 오류: {exc}")
            time.sleep(POLL_INTERVAL)
            continue

        if get_operational_state()["prediction_paused"]:
            # 자동 예측만 멈추고, 현재 winrate.json 값(게이지)은 그대로 유지한다.
            time.sleep(POLL_INTERVAL)
            continue

        try:
            if os.path.exists(INPUT_JSON_PATH):
                current_modified_time = os.path.getmtime(
                    INPUT_JSON_PATH
                )

                if current_modified_time != last_modified_time:
                    with open(INPUT_JSON_PATH, 'r', encoding='utf-8') as f:
                        game_state = json.load(f)

                    red_score = int(game_state['red_score'])
                    blue_score = int(game_state['blue_score'])
                    time_left = int(game_state['time_left'])

                    # 시간이 갑자기 150초로 돌아가면 새 경기로 판단하여
                    # 이전 경기의 lead/goal history가 승률에 영향을 주지 않게 함.
                    if (
                        last_observed_time is not None
                        and time_left > last_observed_time + 10
                    ):
                        reset_prediction_history()

                    feature_row = build_live_feature_row(
                        red_score,
                        blue_score,
                        time_left,
                    )

                    input_array = np.array(
                        [feature_row],
                        dtype=np.float32,
                    )

                    # V5 scaler는 31개 raw feature 전체를 학습한 StandardScaler
                    scaled_data = scaler.transform(
                        input_array
                    )

                    predicted_prob = float(
                        model.predict(
                            scaled_data,
                            verbose=0,
                        )[0][0]
                    )

                    predicted_prob = max(
                        0.0,
                        min(1.0, predicted_prob),
                    )

                    output_data = {
                        "red_winrate": predicted_prob
                    }

                    with open(
                        OUTPUT_JSON_PATH,
                        'w',
                        encoding='utf-8'
                    ) as f:
                        json.dump(
                            output_data,
                            f,
                        )

                    print(
                        f"[업데이트] "
                        f"RED:{red_score} | "
                        f"BLUE:{blue_score} | "
                        f"TIME:{time_left} | "
                        f"RED 승률:{predicted_prob * 100:.2f}%"
                    )

                    last_observed_time = time_left
                    last_modified_time = current_modified_time

        except json.JSONDecodeError:
            # OCR 스레드가 JSON을 쓰는 도중 읽은 경우 다음 cycle에 재시도
            pass
        except KeyError as e:
            print(
                f"에러: 입력 JSON에 필수 데이터가 누락되었습니다. {e}"
            )
        except Exception as e:
            print(
                f"예측 오류: {type(e).__name__}: {e}"
            )

        time.sleep(POLL_INTERVAL)


# ============================================================
# ============================================================
# [3] 최종 중계 화면 / Discord 캡처부 - 원본 3.py 영역
# ============================================================
# ============================================================

WINRATE_FILE = OUTPUT_JSON_PATH
WINDOW_SIZE = (1280, 720)
FPS = 60 # 애니메이션의 부드러움을 위해 30으로 상향

GAUGE_H_RATIO = 0.05

# ------------------------------------------------------------
# 디버깅 설정
# 관리자 창에서 OCR/BBox를 확인합니다.
# 필요할 때만 True로 바꾸면 최종 중계 화면에도 보조 정보를 겹쳐 표시합니다.
# ------------------------------------------------------------
DEBUG_SHOW_ROI = True
SHOW_RELAY_DEBUG = False

# 모던하고 비비드한 e스포츠 컬러 팔레트
RED = (255, 52, 70)       # 쨍한 네온 레드
BLUE = (52, 120, 255)     # 시원한 네온 블루
BG_TOP = (20, 20, 25)     # 상단 게이지 영역 배경 (다크 그레이)
BG_RELAY = (10, 10, 14)   # 화면 캡처 영역 배경
WHITE = (240, 240, 245)
GRAY = (150, 150, 160)
ROI_YELLOW = (255, 220, 70)


def read_winrate(prev):
    try:
        with open(WINRATE_FILE, "r", encoding="utf-8") as f:
            v = float(json.load(f)["red_winrate"])
            return max(0.0, min(1.0, v))
    except Exception:
        return prev


def launch_admin_window():
    """결과 중계와 독립된 관리자 창을 한 번 실행한다."""
    if os.environ.get("BRAWL_DISABLE_ADMIN") == "1":
        return None
    try:
        return subprocess.Popen(
            [sys.executable, os.path.abspath(__file__), "--admin"],
            cwd=BASE_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError as exc:
        print(f"[관리자] 창 실행 실패: {exc}")
        return None


def get_discord_region():
    script = """
    tell application "System Events"
        if exists process "Discord" then
            tell process "Discord"
                if exists window 1 then
                    set {x, y} to position of window 1
                    set {w, h} to size of window 1
                    return (x as string) & "," & (y as string) & "," & (w as string) & "," & (h as string)
                end if
            end tell
        end if
    end tell
    return "None"
    """
    try:
        # osascript는 콘솔 기반으로 실행되므로 Discord 캡처 때문에 별도 GUI 창을 열지 않습니다.
        result = subprocess.check_output(['osascript', '-e', script], text=True).strip()
        if result and result != "None":
            x, y, w, h = map(int, result.split(','))
            if w <= 0 or h <= 0:
                return None
            return {"left": x, "top": y, "width": w, "height": h}
    except Exception:
        pass
    return None


def grab_surface(sct, region):
    if region is None:
        return None
    try:
        shot = sct.grab(region)
        # 원본 3.py의 핵심 최적화 방식 유지
        return pygame.image.frombuffer(shot.rgb, (shot.width, shot.height), "RGB")
    except Exception:
        return None

# 그림자가 포함된 텍스트 렌더링 함수
def draw_text_with_shadow(screen, text, font, color, x, y, align="left"):
    # 그림자(검은색) 생성
    shadow = font.render(text, True, (0, 0, 0))
    # 메인 텍스트 생성
    main_text = font.render(text, True, color)

    # 정렬에 따른 X 좌표 계산
    if align == "center":
        x -= main_text.get_width() // 2
    elif align == "right":
        x -= main_text.get_width()

    # 약간 우측 하단으로 틀어서 그림자 먼저 그리기
    screen.blit(shadow, (x + 2, y + 2))
    # 메인 텍스트 그리기
    screen.blit(main_text, (x, y))


def draw_modern_gauge(screen, w, gauge_h, display_ratio, title_font, perc_font):
    # 상단 헤더 배경색
    pygame.draw.rect(screen, BG_TOP, (0, 0, w, gauge_h))

    margin_x = 60
    bar_w = w - margin_x * 2
    bar_h = 36 # 게이지 바의 두께
    bar_x = margin_x
    bar_y = gauge_h - bar_h - 20 # 아래쪽에 딱 붙게 위치

    red_w = int(bar_w * display_ratio)

    # 텍스트 Y 좌표 (바 위쪽)
    text_y = bar_y - 45

    # 1. 상단 텍스트 정보 (RED팀, 중앙 타이틀, BLUE팀)
    draw_text_with_shadow(screen, f"{display_ratio*100:.1f}%", perc_font, RED, bar_x, text_y, "left")
    draw_text_with_shadow(screen, "LIVE WIN PROBABILITY", title_font, GRAY, w // 2, text_y + 10, "center")
    draw_text_with_shadow(screen, f"{(1-display_ratio)*100:.1f}%", perc_font, BLUE, bar_x + bar_w, text_y, "right")

    # 2. 바 배경 그림자 (입체감 부여)
    pygame.draw.rect(screen, (5, 5, 8), (bar_x, bar_y + 4, bar_w, bar_h), border_radius=18)

    # 3. 블루 바 (전체 배경 역할)
    pygame.draw.rect(screen, BLUE, (bar_x, bar_y, bar_w, bar_h), border_radius=18)

    # 4. 레드 바 (왼쪽 덮어쓰기)
    # red_w가 너무 작으면 오류가 날 수 있으므로 예외 처리 적용하여 둥근 모서리 그리기
    if red_w > 0:
        pygame.draw.rect(
            screen, RED, (bar_x, bar_y, red_w, bar_h),
            border_top_left_radius=18,
            border_bottom_left_radius=18,
            border_top_right_radius=0 if red_w < bar_w - 18 else 18,
            border_bottom_right_radius=0 if red_w < bar_w - 18 else 18
        )

    # 5. 50% 중앙 마커 (흰색 구분선)
    center_x = bar_x + (bar_w // 2)
    pygame.draw.rect(screen, WHITE, (center_x - 2, bar_y - 6, 4, bar_h + 12), border_radius=2)


def get_capture_frame_and_size(capture_state):
    with capture_state["lock"]:
        frame_bytes = capture_state["bytes"]
        frame_size = capture_state["size"]
        region = capture_state["region"]
    return frame_bytes, frame_size, region


def discord_capture_worker(capture_state, region):
    # Discord 캡처 전용 스레드
    sct = mss.mss()
    frame_interval = 1.0 / FPS
    next_frame_time = time.perf_counter()

    # AppleScript 호출은 화면 캡처보다 훨씬 무거우므로 매 프레임 실행하지 않음.
    # Discord 창 이동/크기 변경 대응을 위해 0.5초마다 한 번씩만 위치를 갱신.
    region_refresh_interval = 0.5
    next_region_refresh = 0.0

    while RUNNING.is_set():
        now = time.perf_counter()

        if now >= next_region_refresh:
            current_region = get_discord_region()
            if current_region is not None:
                region.update(current_region)
            next_region_refresh = now + region_refresh_interval

        if region.get("width", 0) > 0 and region.get("height", 0) > 0:
            try:
                shot = sct.grab(region)
                rgb = shot.rgb
                with capture_state["lock"]:
                    capture_state["bytes"] = rgb
                    capture_state["size"] = (shot.width, shot.height)
                    capture_state["region"] = dict(region)
            except Exception:
                pass

        next_frame_time += frame_interval
        sleep_time = next_frame_time - time.perf_counter()
        if sleep_time > 0:
            time.sleep(sleep_time)
        else:
            # 캡처가 잠시 밀렸다면 누적 지연을 제거하여 60 FPS 복귀를 우선
            next_frame_time = time.perf_counter()


def aspect_fit_rect(src_w, src_h, dst_x, dst_y, dst_w, dst_h):
    if src_w <= 0 or src_h <= 0 or dst_w <= 0 or dst_h <= 0:
        return None

    scale = min(dst_w / src_w, dst_h / src_h)
    draw_w = max(1, int(src_w * scale))
    draw_h = max(1, int(src_h * scale))
    draw_x = dst_x + (dst_w - draw_w) // 2
    draw_y = dst_y + (dst_h - draw_h) // 2
    return draw_x, draw_y, draw_w, draw_h


def roi_to_display_rect(roi, capture_region, frame_size, display_rect):
    """
    OCR ROI를 실제 캡처 중인 Discord 창 기준 좌표로 변환한 뒤,
    최종 중계 화면의 aspect-fit 결과에 맞춰 다시 변환합니다.

    기본 discord 모드의 ROI는 이미 Discord 창 내부 좌표다. 이 처리가
    macOS의 창 좌표(point)와 mss 이미지 좌표(pixel)를 섞지 않게 한다.
    """
    if capture_region is None or display_rect is None:
        return None

    x, y, width, height = roi
    if OCR_CAPTURE_SOURCE == "discord":
        # OCR 프레임과 Discord 중계 프레임의 원점이 같음.
        local_x, local_y = x, y
    else:
        monitor_left = monitor.get("left", 0)
        monitor_top = monitor.get("top", 0)
        # monitor 기준 ROI -> 절대 화면 좌표 -> Discord 캡처 영역 좌표
        local_x = monitor_left + x - capture_region["left"]
        local_y = monitor_top + y - capture_region["top"]

    # mss가 반환한 실제 프레임 크기를 사용해야 한다. 창 크기(point)와
    # 프레임 크기(pixel)는 Retina/외부 모니터에서 다를 수 있다.
    source_w, source_h = frame_size

    # ROI가 캡처 영역에 하나도 없으면 표시하지 않음
    if local_x + width <= 0 or local_y + height <= 0:
        return None
    if local_x >= source_w or local_y >= source_h:
        return None

    # 캡처 영역 내부로 클리핑
    left = max(0, local_x)
    top = max(0, local_y)
    right = min(source_w, local_x + width)
    bottom = min(source_h, local_y + height)

    if right <= left or bottom <= top:
        return None

    display_x, display_y, display_w, display_h = display_rect
    scale_x = display_w / source_w
    scale_y = display_h / source_h

    return (
        int(display_x + left * scale_x),
        int(display_y + top * scale_y),
        max(1, int((right - left) * scale_x)),
        max(1, int((bottom - top) * scale_y)),
    )


def draw_debug_roi(screen, capture_region, frame_size, display_rect):
    if not DEBUG_SHOW_ROI or not SHOW_RELAY_DEBUG:
        return

    roi_items = [
        (RED_SCORE_ROI, RED, "RED SCORE"),
        (BLUE_SCORE_ROI, BLUE, "BLUE SCORE"),
        (TIME_ROI, ROI_YELLOW, "TIME"),
    ]

    for roi, color, label in roi_items:
        rect = roi_to_display_rect(roi, capture_region, frame_size, display_rect)
        if rect is None:
            continue

        x, y, w, h = rect
        pygame.draw.rect(screen, color, rect, width=3)

        small_font = pygame.font.SysFont("avenirnext", 16, bold=True)
        label_surface = small_font.render(label, True, color)
        label_bg = pygame.Surface((label_surface.get_width() + 10, label_surface.get_height() + 4), pygame.SRCALPHA)
        label_bg.fill((0, 0, 0, 190))
        screen.blit(label_bg, (x, max(0, y - label_surface.get_height() - 6)))
        screen.blit(label_surface, (x + 5, max(0, y - label_surface.get_height() - 4)))


def draw_debug_status(screen, font, capture_region, frame_size, y):
    """디버그에서 현재 ROI 기준과 실제 캡처 크기를 즉시 확인한다."""
    if not DEBUG_SHOW_ROI or not SHOW_RELAY_DEBUG:
        return
    if capture_region is None:
        text = "OCR/BBox: Discord 창 위치 확인 중"
    else:
        text = (
            f"OCR 기준: Discord 창 내부 좌표 | 캡처: {frame_size[0]}x{frame_size[1]} | "
            f"창: {capture_region['width']}x{capture_region['height']}"
        )
    surface = font.render(text, True, WHITE)
    bg = pygame.Surface((surface.get_width() + 14, surface.get_height() + 8), pygame.SRCALPHA)
    bg.fill((0, 0, 0, 190))
    screen.blit(bg, (8, y))
    screen.blit(surface, (15, y + 4))

def draw_debug_ocr_images(screen, relay_x, relay_y, relay_w, relay_h):
    if not DEBUG_SHOW_ROI or not SHOW_RELAY_DEBUG:
        return

    with DEBUG_OCR_LOCK:
        raw_images = {
            name: None if image is None else image.copy()
            for name, image in DEBUG_RAW_ROI_IMAGES.items()
        }

    panel_w = min(180, relay_w // 4)
    panel_h = 130
    gap = 15

    total_w = panel_w * 3 + gap * 2
    start_x = relay_x + (relay_w - total_w) // 2

    # 화면 하단에 배치
    start_y = relay_y + relay_h - panel_h - 20

    items = [
        ("RED SCORE", RED),
        ("BLUE SCORE", BLUE),
        ("TIME", ROI_YELLOW)
    ]

    small_font = pygame.font.SysFont("avenirnext", 15, bold=True)

    for index, (name, border_color) in enumerate(items):
        x = start_x + index * (panel_w + gap)
        y = start_y

        # 패널 배경
        pygame.draw.rect(
            screen,
            (0, 0, 0),
            (x, y, panel_w, panel_h),
            border_radius=8
        )

        # 테두리
        pygame.draw.rect(
            screen,
            border_color,
            (x, y, panel_w, panel_h),
            width=2,
            border_radius=8
        )

        # 제목
        title_surface = small_font.render(name, True, border_color)
        screen.blit(title_surface, (x + 8, y + 6))

        # 화면에 실제 ROI를 표시한다. OCR에 전달한 이진화 이미지는
        # DEBUG_OCR_IMAGES에 별도로 유지해 필요 시 코드에서 확인할 수 있다.
        image = raw_images.get(name)

        if image is None:
            continue

        # OpenCV grayscale/binary 이미지 -> RGB
        if len(image.shape) == 2:
            image_rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        else:
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        h, w = image_rgb.shape[:2]

        # 패널 안에 종횡비 유지하여 표시
        available_w = panel_w - 16
        available_h = panel_h - 38

        scale = min(
            available_w / w,
            available_h / h
        )

        draw_w = max(1, int(w * scale))
        draw_h = max(1, int(h * scale))

        resized = cv2.resize(
            image_rgb,
            (draw_w, draw_h),
            interpolation=cv2.INTER_NEAREST
        )

        surface = pygame.image.frombuffer(
            resized.tobytes(),
            (draw_w, draw_h),
            "RGB"
        )

        image_x = x + (panel_w - draw_w) // 2
        image_y = y + 30 + (available_h - draw_h) // 2

        screen.blit(surface, (image_x, image_y))


def consume_restart_request():
    """관리자 버튼의 새 재시작 요청을 한 번만 소비한다."""
    global LAST_RESTART_REQUEST_ID
    control = _read_json(ADMIN_CONTROL_FILE, {})
    request_id = control.get("restart_request_id") if isinstance(control, dict) else None
    if request_id is None or request_id == LAST_RESTART_REQUEST_ID:
        return False
    LAST_RESTART_REQUEST_ID = request_id
    return True


def start_worker_threads():
    global OCR_THREAD, PREDICTION_THREAD
    WORKERS_RUNNING.set()
    OCR_THREAD = threading.Thread(target=main_ocr, daemon=True, name="OCR")
    PREDICTION_THREAD = threading.Thread(target=main_prediction, daemon=True, name="Prediction")
    OCR_THREAD.start()
    PREDICTION_THREAD.start()


def restart_workers_in_background():
    """중계 pygame 창은 유지하고 OCR/예측 작업만 새 스레드로 완전히 교체한다."""
    if not WORKER_LOCK.acquire(blocking=False):
        return

    def restart():
        global last_red_score, last_blue_score, last_time_left, last_modified_time, last_observed_time
        try:
            WORKERS_RUNNING.clear()
            for worker in (OCR_THREAD, PREDICTION_THREAD):
                if worker is not None:
                    worker.join(timeout=1.0)
            last_red_score, last_blue_score, last_time_left = 0, 0, 150
            last_modified_time, last_observed_time = 0, None
            reset_prediction_history()
            start_worker_threads()
            print("[관리자] OCR · MLP 작업 재시작 완료")
        finally:
            WORKER_LOCK.release()
    threading.Thread(target=restart, daemon=True, name="PipelineRestart").start()

def main():
    pygame.init()
    # exclusive FULLSCREEN은 macOS에서 포커스를 잃을 때 검정/최소화될 수 있다.
    # 처음에는 일반 창, F키는 무테 데스크톱 창으로 전환한다.
    normal_flags = pygame.RESIZABLE | pygame.DOUBLEBUF
    screen = pygame.display.set_mode(WINDOW_SIZE, normal_flags)
    pygame.display.set_caption("브롤스타즈 실시간 승률 중계")
    clock = pygame.time.Clock()
    admin_process = launch_admin_window()

    # Mac용 모던 폰트
    try:
        title_font = pygame.font.SysFont("avenirnext", 20, bold=True)
        perc_font = pygame.font.SysFont("avenirnext", 42, bold=True)
    except Exception:
        title_font = pygame.font.Font(None, 24)
        perc_font = pygame.font.Font(None, 48)

    # 최신 Discord 캡처 상태
    capture_state = {
        "lock": threading.Lock(),
        "bytes": None,
        "size": (0, 0),
        "region": None,
    }

    discord_region = {"left": 0, "top": 0, "width": 0, "height": 0}
    capture_thread = threading.Thread(
        target=discord_capture_worker,
        args=(capture_state, discord_region),
        daemon=True,
        name="DiscordCapture"
    )
    capture_thread.start()

    target_winrate = 0.5
    display_winrate = 0.5

    # ★ 수정된 부분: 초기 상태가 창 모드이므로 False로 시작해야 토글이 정상 작동합니다.
    fullscreen = False
    running = True
    relay_blackout_until = 0.0

    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif e.key == pygame.K_f:
                    fullscreen = not fullscreen
                    if fullscreen:
                        display_info = pygame.display.Info()
                        screen = pygame.display.set_mode(
                            (display_info.current_w, display_info.current_h),
                            pygame.NOFRAME | pygame.DOUBLEBUF,
                        )
                    else:
                        screen = pygame.display.set_mode(WINDOW_SIZE, normal_flags)

        if consume_restart_request():
            # 시청자 화면은 닫지 않고 잠시 완전 검정으로 송출한다.
            relay_blackout_until = time.perf_counter() + 2.0
            restart_workers_in_background()

        operational_state = get_operational_state()
        target_winrate = read_winrate(target_winrate)

        # =========================================================
        # ★ 1. 단방향 부드러운 수렴 (Lerp) 로직
        # =========================================================
        smoothing_speed = 0.12  # 속도 조절 (0.1 ~ 0.2 추천, 높을수록 빠름)
        diff = target_winrate - display_winrate

        # 목표치를 향해 남은 거리의 일정 비율만큼만 다가감 (스프링처럼 튕기지 않음)
        display_winrate += diff * smoothing_speed

        # ★ 2. 0.3% (0.003) 이내로 근접 시 즉시 정위치로 스냅(Snap)
        if abs(diff) < 0.003:
            display_winrate = target_winrate
        # =========================================================

        w, h = screen.get_size()
        # 경기 종료 상태에서는 상단 승률 게이지 영역 자체를 제거한다.
        gauge_h = 100 if operational_state["game_active"] else 0
        relay_h = max(1, h - gauge_h)

        if time.perf_counter() < relay_blackout_until:
            screen.fill((0, 0, 0))
            pygame.display.update()
            clock.tick(FPS)
            continue

        screen.fill(BG_RELAY)
        if operational_state["game_active"]:
            draw_modern_gauge(screen, w, gauge_h, display_winrate, title_font, perc_font)

        frame_bytes, frame_size, capture_region = get_capture_frame_and_size(capture_state)

        if not operational_state["relay_enabled"]:
            # Discord 창을 감지하지 못하는 비상 상황에서도 게이지는 유지한다.
            msg = title_font.render("The game broadcast has been disabled by operator", True, GRAY)
            screen.blit(
                msg,
                (w // 2 - msg.get_width() // 2, gauge_h + relay_h // 2 - msg.get_height() // 2),
            )
        elif frame_bytes is not None and frame_size[0] > 0 and frame_size[1] > 0:
            source_w, source_h = frame_size

            # 원본 종횡비를 절대 깨지 않고 relay 영역 안에 전체 화면을 표시
            display_rect = aspect_fit_rect(
                source_w,
                source_h,
                0,
                gauge_h,
                w,
                relay_h,
            )

            if display_rect is not None:
                display_x, display_y, display_w, display_h = display_rect
                game_surface = pygame.image.frombuffer(frame_bytes, frame_size, "RGB")

                # crop 없이 전체 화면을 aspect-ratio 보존 방식으로 축소/확대
                if display_w != source_w or display_h != source_h:
                    game_surface = pygame.transform.scale(game_surface, (display_w, display_h))

                screen.blit(game_surface, (display_x, display_y))
                draw_debug_roi(screen, capture_region, frame_size, display_rect)
                draw_debug_status(screen, title_font, capture_region, frame_size, gauge_h + 8)

                draw_debug_ocr_images(
                    screen,
                    display_rect[0],
                    display_rect[1],
                    display_rect[2],
                    display_rect[3]
                )
        else:
            msg = title_font.render("Discord 화면 대기 중...", True, GRAY)
            screen.blit(msg, (w // 2 - msg.get_width() // 2, gauge_h + relay_h // 2))

        # ★ 최적화: 일반 flip() 대신 화면 찢어짐(Tearing)을 방지하고 더 부드럽게 출력
        pygame.display.update()
        clock.tick(FPS)

    RUNNING.clear()
    capture_thread.join(timeout=1.0)
    pygame.quit()


# ============================================================
# 통합 실행부
# ============================================================
RUNNING = threading.Event()
RUNNING.set()
WORKERS_RUNNING = threading.Event()
WORKERS_RUNNING.set()
WORKER_LOCK = threading.Lock()
OCR_THREAD = None
PREDICTION_THREAD = None
LAST_RESTART_REQUEST_ID = None


def integrated_main():
    start_worker_threads()

    try:
        main()
    except KeyboardInterrupt:
        print("\n프로그램을 종료합니다.")
    finally:
        WORKERS_RUNNING.clear()
        RUNNING.clear()


if __name__ == "__main__":
    integrated_main()
